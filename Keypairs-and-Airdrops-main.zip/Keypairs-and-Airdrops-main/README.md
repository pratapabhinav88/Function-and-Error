# Keypairs-and-Airdrops
Contains code for the Keypairs and Airdrops lesson from the Metacrafters beginner Solana course!

[![Open in Gitpod](https://gitpod.io/button/open-in-gitpod.svg)](https://gitpod.io/#https://github.com/Metacrafters/Keypairs-and-Airdrops)
